/* منصة استلام نمو · API
   Reports and approval decisions live in Netlify Blobs (store "receipts").
   Approvers sign in (users from env NMO_USERS, password overrides in Blobs);
   supervisors submit without an account and fix returned reports with a per-report key. */
import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";
import NMO from "./lib/shared.mjs";
import PROPS from "./lib/props.mjs";

const FINAL = NMO.APPROVERS.length + 1;               // stage after the last approval
const FORMS = {
  tenant: "f8608e53-90dc-4efc-a1af-0ed4abd44b53", owner: "857cd398-b476-4246-baea-0885abba66d0",
  base: "https://forms.cloud.microsoft",
  report: { id: "U45g-NyQ_E6hrw7Uq9RLU5jTfIV2tEZCuuoIhau6ZtBUQ0FLNVhGV1kwOVZDTkU5MUxGSzdMTVdFTC4u", q: { ref: "rec602d5837894ee6b4f7d40ac9b70cec", code: "r03d262169573466c8210123ddca3cacd", name: "r6ce9819dbca249cab099348725e2d6b2", sup: "r4155f724d802414b94f446cb8a912134", phone: "rc081f153df5944d1a31a04721f55bef8", email: "r65b1111711514457ace11fc568759b88", status: "rcf8b64457f544c08bc75d1bd6db35404", teams: "r283191bb71f34a9b98f676287f942752", verify: "re313c6cd32604614890599d171bb9788", waqf: "ra7d4468b61344f539ad4f5890a2419fd", docs: "rac8ae4810d7d416081f380ec5532307d", vac: "r5415e439939f4670b3ee77e9803471d0", off: "r002acaadfcf64f32b7f974dedce037b5", arr: "r6b5e542696ef4ac794627c19f6bc58b4", mnt: "ra8401ff2f2bc49c3ad7ac0551a244008", meters: "re32e23a2c1b74674b5164640ab689460", viol: "rbdbb78288fb0408080fe24a1ba770c82", opp: "reba8f252d3ba46dfa0a97be79c726036", notes: "r715abd3a9fe54e4887b6f08e9259573c", files: "r0cecda9089ad437c9c618a082a0ace01", link: "r366a7e411b584a6ea2b9f0abf7d656e8" } },
  decision: { id: "U45g-NyQ_E6hrw7Uq9RLU5jTfIV2tEZCuuoIhau6ZtBURjFZRUkxSjBEOEE2NzdVUUtTRU1QMkZLTy4u", q: { ref: "r8e3373296993436f8b865139570e8831", code: "r9b56a8f3fb584187aa9a65a5a34f2c3e", name: "r73a64d99a42545b49820377838e556ef", stage: "r0eca5185d1db40a98de9a7302f664ae3", approver: "r925537356ebd413eb49b74ce20bb333c", decision: "ra19d9cb1b93a48dfa2ee3d053793eac6", note: "rf6a4e3b177694fc7bb4a2a1956664926", edits: "r4d3c1fdcdc1341cf8e1e45d92ab14fd9", status: "rba6cdf0c6e104128b2b83647f3f9d4a9", next: "r81fdb4b6fb4547b0a7d396aea934bba3", link: "r936a100eb32b4c1faa102101b369ee23" } }
};

/* ---------- helpers ---------- */
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
const fail = (msg, status = 400) => json({ error: msg }, status);
const db = () => getStore({ name: "receipts", consistency: "strong" });
const now = () => new Date().toISOString();
const b64u = b => Buffer.from(b).toString("base64url");
const rand = n => crypto.randomBytes(n).toString("base64url").replace(/[-_]/g, "").slice(0, n);
const clean = (v, max) => String(v == null ? "" : v).replace(/[\u0000-\u001f]/g, " ").trim().slice(0, max);
const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
async function body(req, max = 150000) { const t = await req.text(); if (t.length > max) throw Object.assign(new Error("too large"), { status: 413 }); try { return JSON.parse(t || "{}"); } catch { throw Object.assign(new Error("bad json"), { status: 400 }); } }

/* ---------- users & sessions ---------- */
function users() {
  let list = [];
  try { list = JSON.parse(Netlify.env.get("NMO_USERS") || "[]"); } catch { }
  return list.map(u => { const a = NMO.APPROVERS.find(x => x.stage === u.s) || {}; return { e: u.e.toLowerCase(), s: u.s, h: u.h, admin: !!u.admin, n: u.n || a.name, role: u.r || a.role }; });
}
const pub = u => ({ email: u.e, name: u.n, stage: u.s, role: u.role, admin: u.admin });
function hashPw(pw, salt = crypto.randomBytes(16)) { const h = crypto.scryptSync(String(pw), salt, 32); return `scrypt$${b64u(salt)}$${b64u(h)}`; }
function checkPw(pw, stored) { const [k, s, h] = String(stored || "").split("$"); if (k !== "scrypt" || !s || !h) return false; const x = crypto.scryptSync(String(pw), Buffer.from(s, "base64url"), 32); return safeEq(b64u(x), h); }
const secret = () => Netlify.env.get("NMO_SECRET") || "";
function sign(payload) { const p = b64u(JSON.stringify(payload)); return p + "." + b64u(crypto.createHmac("sha256", secret()).update(p).digest()); }
function verify(tok) {
  const [p, sig] = String(tok || "").split(".");
  if (!p || !sig || !secret()) return null;
  if (!safeEq(b64u(crypto.createHmac("sha256", secret()).update(p).digest()), sig)) return null;
  try { const o = JSON.parse(Buffer.from(p, "base64url").toString()); return o.x > Date.now() ? o : null; } catch { return null; }
}
async function auth(req) {
  const t = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  const o = verify(t); if (!o) return null;
  const u = users().find(x => x.e === o.e); if (!u) return null;
  const pw = await db().get("pw/" + u.e, { type: "json" });
  if (pw && pw.v !== o.v) return null;                  // password changed since this token was issued
  return u;
}
async function login(req) {
  const { email, password } = await body(req, 2000);
  const e = clean(email, 120).toLowerCase(), u = users().find(x => x.e === e);
  const s = db(), lk = "lock/" + (e || "-");
  const lock = await s.get(lk, { type: "json" }) || { n: 0, t: 0 };
  if (lock.n >= 8 && Date.now() - lock.t < 10 * 60e3) return fail("محاولات كثيرة. حاول بعد عشر دقائق.", 429);
  const pw = u ? await s.get("pw/" + u.e, { type: "json" }) : null;
  const ok = u && checkPw(password, pw ? pw.h : u.h);
  if (!ok) { await s.setJSON(lk, { n: (Date.now() - lock.t < 10 * 60e3 ? lock.n : 0) + 1, t: Date.now() }); await new Promise(r => setTimeout(r, 400)); return fail("البريد أو كلمة المرور غير صحيحة.", 401); }
  await s.delete(lk);
  return json({ token: sign({ e: u.e, v: pw ? pw.v : 0, x: Date.now() + 30 * 864e5 }), user: pub(u) });
}
async function changePw(req, u) {
  const { current, next } = await body(req, 2000);
  const s = db(), pw = await s.get("pw/" + u.e, { type: "json" });
  if (!checkPw(current, pw ? pw.h : u.h)) return fail("كلمة المرور الحالية غير صحيحة.", 400);
  if (String(next || "").length < 8) return fail("كلمة المرور الجديدة ثمانية أحرف على الأقل.", 400);
  const v = (pw ? pw.v : 0) + 1;
  await s.setJSON("pw/" + u.e, { h: hashPw(next), v, at: now() });
  return json({ ok: true, token: sign({ e: u.e, v, x: Date.now() + 30 * 864e5 }) });
}

/* ---------- reports ---------- */
const strip = r => { const { key, ...rest } = r; return rest; };
function propFor(code, custom) {
  if (code && code !== "OTHER") { const p = PROPS.find(x => x.code === code); if (p) return { code: p.code, name: p.name, district: p.district, type: p.type, units: p.units, lat: p.lat, lng: p.lng, unitList: p.unitList }; }
  return { code: "غير مدرج", name: clean(custom && custom.name, 80) || "عقار غير مدرج", district: clean(custom && custom.loc, 120), type: "", units: null, unitList: [] };
}
function sanitizeA(A) { const b = NMO.blank(); if (!A || typeof A !== "object") return b; Object.keys(b).forEach(k => { if (A[k] !== undefined) b[k] = A[k]; }); return b; }
function summary(r) {
  const f = NMO.analyze(Object.assign(NMO.blank(), r.A), r.prop || {}), last = (r.chain || []).slice(-1)[0];
  return {
    id: r.id, ref: r.ref, at: r.at, updated: r.updated, stage: r.stage, stageAt: r.stageAt, retTo: r.retTo || null,
    code: r.prop.code, name: r.prop.name, district: r.prop.district, type: r.prop.type, units: r.prop.units,
    sup: r.sup.name, phone: r.sup.phone, status: NMO.statusOf(f),
    red: f.filter(x => x.lvl === "red").length, amber: f.filter(x => x.lvl === "amber").length, opp: f.filter(x => x.lvl === "opp").length,
    upl: r.A && r.A.upl, last: last ? { n: last.n, d: last.d, s: last.s, to: last.to, at: last.at, note: last.note } : null,
    edits: (r.chain || []).reduce((n, e) => n + (e.edits ? e.edits.length : 0), 0) + (r.pend ? r.pend.edits.length : 0)
  };
}
async function all() {
  const s = db(), { blobs } = await s.list({ prefix: "r/" });
  const out = [];
  for (let i = 0; i < blobs.length; i += 25) out.push(...await Promise.all(blobs.slice(i, i + 25).map(b => s.get(b.key, { type: "json" }))));
  return out.filter(Boolean);
}
const recKey = id => "r/" + String(id).replace(/[^\w-]/g, "");
/* read with its etag; every write is conditional on it, so two people (or two tabs) can never overwrite each other */
async function getRec(id) { const x = await db().getWithMetadata(recKey(id), { type: "json" }); if (!x || !x.data) return null; Object.defineProperty(x.data, "_etag", { value: x.etag, enumerable: false }); return x.data; }
async function putRec(r, fresh) {
  r.updated = now();
  const res = await db().setJSON("r/" + r.id, r, fresh ? { onlyIfNew: true } : r._etag ? { onlyIfMatch: r._etag } : {});
  if (res && res.modified === false) throw Object.assign(new Error("conflict"), { status: 409 });
}
function mergeEdits(prev, d) { const m = (prev || []).map(x => Object.assign({}, x)); d.forEach(x => { const y = m.find(z => z.l === x.l); if (y) y.t = x.t; else m.push(x); }); return m.filter(x => x.f !== x.t); }

async function submit(req, ctx) {
  const b = await body(req);
  const sup = { name: clean(b.sup && b.sup.name, 60), phone: clean(b.sup && b.sup.phone, 16).replace(/[\s-]/g, ""), email: clean(b.sup && b.sup.email, 80) };
  if (sup.name.split(/\s+/).length < 2 || !/^(05\d{8}|\+?9665\d{8})$/.test(sup.phone)) return fail("بيانات المشرف ناقصة.");
  const prop = propFor(clean(b.code, 20), b.custom), A = sanitizeA(b.A);
  const miss = NMO.reqs(A, prop).filter(x => !x.ok);
  if (miss.length) return fail("التقرير ناقص: " + miss.slice(0, 3).map(m => m.label).join("، "));
  const ref = /^R-[\w]+-\d{6}-\d{4}$/.test(b.ref || "") ? b.ref : "R-" + rand(6);
  const r = { v: 2, id: ref + "-" + rand(4).toLowerCase(), ref, at: now(), sup, prop, A, chain: [], stage: 1, stageAt: now(), retTo: null, pend: null, key: rand(18) };
  await putRec(r, true);
  ctx.waitUntil(mirrorReport(r, new URL(req.url).origin).catch(e => console.error("mirror report", e)));
  return json({ id: r.id, ref: r.ref, key: r.key, stage: r.stage, next: NMO.holder(1) });
}
async function editAnswers(req, u, r) {
  if (r.stage !== u.s) return fail("التقرير ليس في مرحلتك الآن.", 409);
  const b = await body(req), A = sanitizeA(b.A);
  const miss = NMO.reqs(A, r.prop).filter(x => !x.ok && x.id !== "ack");
  if (miss.length) return fail("بنود ناقصة: " + miss.slice(0, 3).map(m => m.label).join("، "));
  const d = NMO.diffA(Object.assign(NMO.blank(), r.A), A, r.prop);
  const edits = mergeEdits(r.pend && r.pend.e === u.e ? r.pend.edits : [], d);
  A.ack = r.A.ack; r.A = A; r.pend = edits.length ? { s: u.s, e: u.e, n: u.n, edits, at: now() } : null;
  await putRec(r);
  return json({ report: strip(r) });
}
async function decide(req, u, r, ctx) {
  if (r.stage !== u.s) return fail("التقرير ليس في مرحلتك الآن.", 409);
  const b = await body(req, 5000), d = b.d === "ok" ? "ok" : b.d === "back" ? "back" : null;
  if (!d) return fail("القرار غير معروف.");
  const note = clean(b.note, 500);
  let to;
  if (d === "back") { if (note.length < 3) return fail("اكتب سبب الإعادة."); to = Number.isInteger(b.to) && b.to >= 0 && b.to < u.s ? b.to : u.s - 1; }
  const entry = { s: u.s, n: u.n, e: u.e, d, note, at: now(), edits: r.pend && r.pend.e === u.e ? r.pend.edits : [] };
  if (d === "back") entry.to = to;
  r.chain.push(entry); r.pend = null;
  r.stage = d === "ok" ? u.s + 1 : to; r.stageAt = now();
  if (d === "back") r.retTo = u.s;
  await putRec(r);
  const origin = new URL(req.url).origin;
  ctx.waitUntil(mirrorDecision(r, entry, origin).catch(e => console.error("mirror decision", e)));
  return json({ report: strip(r), fixLink: d === "back" && to === 0 ? `${origin}/#fix=${r.id}.${r.key}` : null });
}
async function resubmit(req, r, ctx) {
  const b = await body(req);
  if (!safeEq(b.key || "", r.key)) return fail("الرابط غير صالح.", 403);
  if (r.stage !== 0) return fail("التقرير ليس معاداً إليك.", 409);
  const A = sanitizeA(b.A), miss = NMO.reqs(A, r.prop).filter(x => !x.ok);
  if (miss.length) return fail("التقرير ناقص: " + miss.slice(0, 3).map(m => m.label).join("، "));
  const to = r.retTo && r.retTo <= NMO.APPROVERS.length ? r.retTo : 1;
  const entry = { s: 0, n: r.sup.name, d: "resend", to, note: clean(b.note, 500), at: now(), edits: NMO.diffA(Object.assign(NMO.blank(), r.A), A, r.prop) };
  r.A = A; r.chain.push(entry); r.stage = to; r.stageAt = now();
  await putRec(r);
  ctx.waitUntil(mirrorDecision(r, entry, new URL(req.url).origin).catch(e => console.error("mirror resend", e)));
  return json({ ok: true, stage: r.stage, next: NMO.holder(r.stage) });
}

/* ---------- copy to Microsoft Forms → Excel (best effort; never blocks the platform) ---------- */
async function formsPost(form, vals) {
  const page = await fetch(`${FORMS.base}/Pages/ResponsePage.aspx?id=${form.id}`, { headers: { "user-agent": "Mozilla/5.0 NMO-platform" } });
  const html = await page.text();
  const tok = (html.match(/"antiForgeryToken"\s*:\s*"([^"]+)"/) || [])[1] || "";
  const cookies = (page.headers.getSetCookie ? page.headers.getSetCookie() : []).map(c => c.split(";")[0]).join("; ");
  const answers = Object.entries(form.q).filter(([k]) => vals[k]).map(([k, qid]) => ({ questionId: qid, answer1: String(vals[k]).slice(0, 3900) }));
  const t = now();
  const res = await fetch(`${FORMS.base}/formapi/api/${FORMS.tenant}/users/${FORMS.owner}/forms('${form.id}')/responses`, {
    method: "POST",
    headers: { "content-type": "application/json", accept: "application/json", "odata-version": "4.0", "x-usersessionid": crypto.randomUUID(), "x-ms-form-request-source": "ms-formweb", "x-ms-form-request-ring": "business", ...(tok ? { __requestverificationtoken: tok } : {}), ...(cookies ? { cookie: cookies } : {}), origin: FORMS.base, referer: `${FORMS.base}/Pages/ResponsePage.aspx?id=${form.id}`, "user-agent": "Mozilla/5.0 NMO-platform" },
    body: JSON.stringify({ startDate: t, submitDate: t, answers: JSON.stringify(answers) })
  });
  return res.status;
}
const noteMirror = (id, k, status) => db().setJSON(`m/${id}/${k}`, { status, at: now() });   // own key: never touches the report record
const isTest = r => /^R-TEST-/.test(r.ref);
async function mirrorReport(r, origin) {
  if (isTest(r)) return;
  const vals = NMO.formsFields(Object.assign({}, r, { link: `${origin}/approvals#r=${r.id}` }));
  await noteMirror(r.id, "report", await formsPost(FORMS.report, vals));
}
async function mirrorDecision(r, e, origin) {
  if (isTest(r)) return;
  const vals = { ref: r.ref, code: r.prop.code, name: r.prop.name, stage: e.s === 0 ? "المشرف" : `${e.s} · ${e.n}`, approver: e.n, decision: { ok: "اعتماد", back: "إعادة", resend: "إعادة إرسال" }[e.d], note: e.note, edits: (e.edits || []).map(x => `${x.l}: ${x.f || "—"} ← ${x.t || "—"}`).join(" | "), status: NMO.chainState(r.stage), next: NMO.holder(r.stage) || "—", link: `${origin}/approvals#r=${r.id}` };
  await noteMirror(r.id, "decision" + r.chain.length, await formsPost(FORMS.decision, vals));
}

/* ---------- router ---------- */
export default async (req, ctx) => {
  const url = new URL(req.url), p = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean), m = req.method;
  try {
    if (p[0] === "login" && m === "POST") return await login(req);
    if (p[0] === "reports" && p.length === 1 && m === "POST") return await submit(req, ctx);
    if (p[0] === "reports" && p[1] && url.searchParams.get("key") && m === "GET") {        // supervisor: track / fix
      const r = await getRec(p[1]); if (!r || !safeEq(url.searchParams.get("key"), r.key)) return fail("الرابط غير صالح.", 404);
      return json({ report: strip(r), next: NMO.holder(r.stage) });
    }
    if (p[0] === "reports" && p[1] && p[2] === "resubmit" && m === "POST") { const r = await getRec(p[1]); if (!r) return fail("غير موجود", 404); return await resubmit(req, r, ctx); }

    const u = await auth(req); if (!u) return fail("سجّل الدخول.", 401);
    if (p[0] === "me") return json({ user: pub(u) });
    if (p[0] === "password" && m === "POST") return await changePw(req, u);
    if (p[0] === "reports" && p.length === 1 && m === "GET") { const list = await all(); return json({ reports: list.map(summary).sort((a, b) => (b.stageAt || b.at).localeCompare(a.stageAt || a.at)), user: pub(u) }); }
    if (p[0] === "export" && m === "GET") { const list = await all(); return json({ reports: list.map(strip) }); }
    if (p[0] === "reports" && p[1]) {
      const r = await getRec(p[1]); if (!r) return fail("التقرير غير موجود.", 404);
      if (!p[2] && m === "GET") return json({ report: strip(r) });
      if (p[2] === "mirror" && m === "GET") { const { blobs } = await db().list({ prefix: `m/${r.id}/` }); return json({ mirror: await Promise.all(blobs.map(async b => [b.key.split("/").pop(), await db().get(b.key, { type: "json" })])) }); }
      if (!p[2] && m === "DELETE") { if (!u.admin) return fail("غير مسموح.", 403); const s = db(), { blobs } = await s.list({ prefix: `m/${r.id}/` }); await Promise.all(blobs.map(b => s.delete(b.key))); await s.delete("r/" + r.id); return json({ ok: true }); }
      if (p[2] === "edit" && m === "POST") return await editAnswers(req, u, r);
      if (p[2] === "decision" && m === "POST") return await decide(req, u, r, ctx);
      if (p[2] === "fixlink" && m === "GET") return json({ link: `${url.origin}/#fix=${r.id}.${r.key}` });
    }
    return fail("غير موجود", 404);
  } catch (e) {
    console.error(e);
    return fail(e.status === 409 ? "تغيّر التقرير للتو من شخص آخر. حدّث الصفحة ثم حاول مرة أخرى." : e.status === 413 ? "حجم البيانات كبير." : e.status ? "طلب غير صالح." : "خطأ في الخادم. حاول مرة أخرى.", e.status || 500);
  }
};

export const config = { path: "/api/*" };
